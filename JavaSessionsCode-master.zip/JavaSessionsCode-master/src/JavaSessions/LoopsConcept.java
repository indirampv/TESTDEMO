package JavaSessions;

public class LoopsConcept {

	public static void main(String[] args) {

		//1. while loop:
		//print 1 to 10:
		int i = 1; //Initialization
		while(i<=10){ //Conditional
			System.out.println(i);
			i++; //Incremental
		}
		
		System.out.println("******");
		
		//2. for loop:
		for(int j=1; j<=10; j++){
			System.out.println(j);
		}
		
		//print 10 to 1
		
		
	}

}
